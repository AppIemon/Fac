#!/usr/bin/env bash
# Fac Iron Factory - Paper 26.2 server. Requires Java 25+. First launch downloads Paper (one-time).
set -e
cd "$(dirname "$0")"
JAR=paper-26.2-119.jar
URL="https://fill-data.papermc.io/v1/objects/a8c9140c3075bd7c04973e9cdc491b21bfe6bad472b674ef932a4ae0fec19629/paper-26.2-119.jar"
if [ ! -f "$JAR" ]; then
  echo "[Fac] Downloading Paper 26.2 (one-time)..."
  curl -fL -o "$JAR" "$URL" || wget -O "$JAR" "$URL"
fi
exec java -Xms1G -Xmx2G -jar "$JAR" nogui
