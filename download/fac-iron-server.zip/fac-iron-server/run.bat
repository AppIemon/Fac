@echo off
rem Fac Iron Factory - Paper 26.2 server. Requires Java 25+. First launch downloads Paper (one-time).
cd /d "%~dp0"
set JAR=paper-26.2-119.jar
if not exist "%JAR%" (
  echo [Fac] Downloading Paper 26.2 ^(one-time^)...
  powershell -Command "Invoke-WebRequest -Uri 'https://fill-data.papermc.io/v1/objects/a8c9140c3075bd7c04973e9cdc491b21bfe6bad472b674ef932a4ae0fec19629/paper-26.2-119.jar' -OutFile '%JAR%'"
)
java -Xms1G -Xmx2G -jar "%JAR%" nogui
pause
